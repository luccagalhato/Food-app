class ColorsConst {
  static const iconBottomColor = 0xff989898;
  static const bottomBarColor = 0xffffffff;
  static const bodyColor = 0xfff2f2f4;
  static const cardSelected = 0xffffcc2a;
}
